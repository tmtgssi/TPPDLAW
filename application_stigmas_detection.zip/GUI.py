import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
from PIL import Image, ImageTk
import os
import cv2
from ultralytics import YOLO

def load_image():
    file_path = filedialog.askopenfilename(
        title="Select an Image",
        initialdir=os.getcwd(),
        filetypes=[("All Files", "*.*")]
    )
    
    if file_path:
        try:
            img = Image.open(file_path)
            img.thumbnail((400, 400), Image.Resampling.LANCZOS)  # Resize for display
            img = ImageTk.PhotoImage(img)
            
            input_image_label.config(image=img)
            input_image_label.image = img  
            
            image_path.set(file_path)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load image: {e}")

def check_image():
    image_path_val = image_path.get()
    if not image_path_val:
        messagebox.showwarning("No Image", "Please load an image first.")
        return
    
    model_choice = model_var.get()
    model_path = model_paths.get(model_choice)
    if not model_path:
        messagebox.showwarning("No Model", "Please select a model.")
        return
    
    # Set device to CPU only
    device_choice = "cpu"  
    
    output_dir = './results'
    os.makedirs(output_dir, exist_ok=True)
    
    result_text = run_inference(image_path_val, model_path, output_dir, device_choice)
    
    result_text_box.delete(1.0, tk.END)  
    result_text_box.insert(tk.END, result_text)  

    # Display output image after detection
    output_img = Image.open(os.path.join(output_dir, os.path.basename(image_path_val)))
    output_img.thumbnail((400, 400), Image.Resampling.LANCZOS)  # Resize for display
    output_img = ImageTk.PhotoImage(output_img)
    
    output_image_label.config(image=output_img)
    output_image_label.image = output_img  

def run_inference(image_path, model_path, output_dir, device_choice):
    model = YOLO(model_path)
    results = model.predict(source=image_path, device=device_choice, save=False)
    
    result_text = ''
    target_class_id = 1  # Assuming the target class is 1 (adjust as needed)

    for i, result in enumerate(results):
        original_image = result.orig_img.copy()  # Original image for size reference
        original_width, original_height = original_image.shape[1], original_image.shape[0]
        
        result_text += f"Original Image Size: {original_width}x{original_height}\n"

        for box in result.boxes:
            cls_id = int(box.cls[0])
            if cls_id == target_class_id:
                xyxy = box.xyxy[0].cpu().numpy().astype(int)
                conf = float(box.conf[0])
                label = f"{model.names[cls_id]}"
                
                # For drawing the bounding box on the original image
                x1, y1, x2, y2 = xyxy
                cv2.rectangle(original_image, (x1, y1), (x2, y2), (0, 255, 0), 4)
                
                # Scale the bounding box coordinates for the resized image (400px display size)
                scale_factor_x = 400 / original_width
                scale_factor_y = 400 / original_height

                scaled_x1 = int(x1 * scale_factor_x)
                scaled_y1 = int(y1 * scale_factor_y)
                scaled_x2 = int(x2 * scale_factor_x)
                scaled_y2 = int(y2 * scale_factor_y)

                # Add scaled coordinates to result text for the resized image

                result_text += f"Stigma Location: ({x1}, {y1}) to ({x2}, {y2})\n"
        
        filename = os.path.basename(result.path)
        output_path = os.path.join(output_dir, filename)
        cv2.imwrite(output_path, original_image)  # Save the image with bounding boxes in original size
    
    return result_text

root = tk.Tk()
root.title("Stigmas Detection")
root.geometry("630x1000")
root.configure(bg="#f4f4f9")  

# Configure grid to make it more responsive
root.grid_rowconfigure(0, weight=1)
root.grid_rowconfigure(1, weight=2)
root.grid_rowconfigure(2, weight=1)
root.grid_rowconfigure(3, weight=1)
root.grid_rowconfigure(4, weight=1)
root.grid_rowconfigure(5, weight=1)
root.grid_rowconfigure(6, weight=1)
root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)
root.grid_columnconfigure(2, weight=1)

# Header Section
header_frame = tk.Frame(root, bg="#f4f4f9")
header_frame.grid(row=0, column=0, columnspan=3, pady=10, sticky="nsew")
name_label = tk.Label(header_frame, text="Stigmas Detection", font=("Arial", 20, "bold"), bg="#f4f4f9")
name_label.pack(side="top", padx=20)

# Image Display Section
image_frame = tk.Frame(root)
image_frame.grid(row=1, column=0, columnspan=3, pady=20, sticky="nsew")

input_image_label = tk.Label(image_frame, bg="#f4f4f9", relief="solid")
input_image_label.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")

output_image_label = tk.Label(image_frame, bg="#f4f4f9", relief="solid")
output_image_label.grid(row=0, column=1, padx=20, pady=20, sticky="nsew")

# Load Button
load_button = tk.Button(root, text="Load Image", command=load_image, font=("Arial", 14), bg="#007BFF", fg="white", relief="raised", bd=2)
load_button.grid(row=2, column=0, columnspan=3, pady=10, padx=20, sticky="ew")

# Model Selection
model_var = tk.StringVar()  
model_paths = {
    'YOLO v8': './ckpt/yolov8.pt',
    'YOLO v9': './ckpt/yolov9.pt',
    'YOLO v10': './ckpt/yolov10.pt',
    'YOLO v11': './ckpt/yolov11.pt',
    'YOLO v12': './ckpt/yolov12.pt',
}

model_var.set('YOLO v8')  

model_label = tk.Label(root, text="Select Model:", font=("Arial", 14), bg="#f4f4f9")
model_label.grid(row=3, column=0, pady=5, padx=20, sticky="w")

model_menu = ttk.Combobox(root, textvariable=model_var, values=list(model_paths.keys()), font=("Arial", 14), state="readonly")
model_menu.grid(row=3, column=1, pady=10, padx=20, sticky="ew")


device_var = tk.StringVar(value="cpu")  

# Detect Button
check_button = tk.Button(root, text="DETECT", command=check_image, font=("Arial", 14), bg="#28a745", fg="white", relief="raised", bd=2)
check_button.grid(row=5, column=0, columnspan=3, pady=10, padx=20, sticky="ew")

# Result Display
result_text_box = tk.Text(root, height=8, width=40, font=("Arial", 12))
result_text_box.grid(row=6, column=0, columnspan=3, pady=20, padx=20)

# Exit Button
exit_button = tk.Button(root, text="Exit", command=root.quit, font=("Arial", 14), bg="#dc3545", fg="white", relief="raised", bd=2)
exit_button.grid(row=7, column=0, columnspan=3, pady=20, padx=20, sticky="ew")

# Store the image path
image_path = tk.StringVar()

root.mainloop()

