import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
from PIL import Image, ImageTk
import os
import cv2
from ultralytics import YOLO

# Function to open an image file and display it in the first window
def load_image():
    # Open file dialog to select an image
    file_path = filedialog.askopenfilename(
        title="Select an Image",
        initialdir=os.getcwd(),
        filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.bmp;*.gif"), ("All Files", "*.*")]
    )
    
    if file_path:
        try:
            img = Image.open(file_path)
            img.thumbnail((400, 400))  # Resize the image for display
            img = ImageTk.PhotoImage(img)
            
            # Update the input image display label
            input_image_label.config(image=img)
            input_image_label.image = img  # Keep reference
            
            # Set the image path in the variable
            image_path.set(file_path)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load image: {e}")

# Function to run the inference and display the output
def check_image():
    image_path_val = image_path.get()
    if not image_path_val:
        messagebox.showwarning("No Image", "Please load an image first.")
        return
    
    model_choice = model_var.get()
    model_path = model_paths.get(model_choice)
    if not model_path:
        messagebox.showwarning("No Model", "Please select a model.")
        return
    
    output_dir = './Yolo_v8_results'
    os.makedirs(output_dir, exist_ok=True)
    
    # Run inference
    result_text = run_inference(image_path_val, model_path, output_dir)
    
    # Display results in the text box
    result_text_box.delete(1.0, tk.END)  # Clear any previous text
    result_text_box.insert(tk.END, result_text)  # Display the result

    # Load and display the output image
    output_img = Image.open(os.path.join(output_dir, os.path.basename(image_path_val)))
    output_img.thumbnail((400, 400))  # Resize
    output_img = ImageTk.PhotoImage(output_img)
    
    output_image_label.config(image=output_img)
    output_image_label.image = output_img  # Keep reference

# Function to run YOLO inference and save the result
def run_inference(image_path, model_path, output_dir):
    model = YOLO(model_path)
    results = model.predict(source=image_path, device='cpu', save=False)
    
    result_text = ''
    target_class_id = 1  # Assuming stigmas are in class 1

    for i, result in enumerate(results):
        image = result.orig_img.copy()
        for box in result.boxes:
            cls_id = int(box.cls[0])
            if cls_id == target_class_id:
                xyxy = box.xyxy[0].cpu().numpy().astype(int)
                conf = float(box.conf[0])
                label = f"{model.names[cls_id]}"
                # Draw bounding box
                cv2.rectangle(image, tuple(xyxy[:2]), tuple(xyxy[2:]), (0, 255, 0), 4)
                result_text += f"Class: {label}, Conf: {conf:.2f}, Location: {xyxy[:2]} to {xyxy[2:]}\n"
        
        filename = os.path.basename(result.path)
        output_path = os.path.join(output_dir, filename)
        cv2.imwrite(output_path, image)
    
    return result_text

# Main window setup
root = tk.Tk()
root.title("AI Image Checker")
root.geometry("1000x800")
root.configure(bg="#f4f4f9")  # Light background color for a modern feel

# Header and Logo (optional)
header_frame = tk.Frame(root, bg="#f4f4f9")
header_frame.pack(fill="x", pady=10)

name_label = tk.Label(header_frame, text="GSSI - Computer Science", font=("Arial", 20, "bold"), bg="#f4f4f9")
name_label.pack(side="left", padx=10)

# Image display section for input and output
input_image_label = tk.Label(root, bg="#f4f4f9")  # Input image label
input_image_label.pack(side="left", padx=20, pady=20)

output_image_label = tk.Label(root, bg="#f4f4f9")  # Output image label
output_image_label.pack(side="left", padx=20, pady=20)

# Load button to load image
load_button = tk.Button(root, text="Load Image", command=load_image, font=("Arial", 14), bg="#007BFF", fg="white", relief="raised", bd=2)
load_button.pack(pady=10)

# Dropdown for model selection
model_var = tk.StringVar()  # Store model selection
model_paths = {
    'YOLO v8': './ckpt/yolo_v8.pth',
    'YOLO v9': './ckpt/yolo_v9.pth',
    'YOLO v10': './ckpt/yolo_v10.pth',
    'YOLO v11': './ckpt/yolo_v11.pth',
    'YOLO v12': './ckpt/yolo_v12.pth',
}

model_var.set('YOLO v8')  # Default to YOLO v8

model_label = tk.Label(root, text="Select Model:", font=("Arial", 14), bg="#f4f4f9")
model_label.pack(pady=5)

model_menu = ttk.Combobox(root, textvariable=model_var, values=list(model_paths.keys()), font=("Arial", 14), state="readonly")
model_menu.pack(pady=10)

# Button to check if the image is AI or not
check_button = tk.Button(root, text="CHECK", command=check_image, font=("Arial", 14), bg="#28a745", fg="white", relief="raised", bd=2)
check_button.pack(pady=10)

# Text box to display the result
result_text_box = tk.Text(root, height=10, width=40, font=("Arial", 12))
result_text_box.pack(pady=20)

# Store the image path for checking later
image_path = tk.StringVar()

# Start the GUI loop
root.mainloop()
